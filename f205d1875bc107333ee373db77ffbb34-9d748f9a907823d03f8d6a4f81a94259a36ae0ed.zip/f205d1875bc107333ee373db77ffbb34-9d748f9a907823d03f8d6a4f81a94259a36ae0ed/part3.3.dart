mixin Run {
void run() {
print('Running...');
}
}
class Dog with Run {}
void main() {
var dog = Dog();
bird.run();
}
